$(document).ready(function() {
	var fixControls = function() {

		var top = ($(window).height()-777)/2;
		if ($(window).height() > 777) {
			$("#controls").css("top",(606 + top));
			$("#wrapper1").css("margin-top", top);
		}
		else {

			$("#controls").css("top","auto");
		}
	}
	fixControls();
	$(window).resize(function() {
		
		fixControls();
	})
	var init = function() {

		var sLeft = $(this).scrollLeft();
		$(".first").css({'left':(11970 - 8500)/(11970 - $(window).width()) * sLeft});
		$(".seconda").css({'left': (11970 - 10200)/(11970 - $(window).width()) * sLeft});
		$(".secondb").css({'left': (11970 - 10200)/(11970 - $(window).width()) * sLeft});
	}
	init();
	$(window).scroll(init);
	var pagenum = 1;
	
	
				
						
	var speedcoef = 2.2;
	$("#controls .button4").click(function() {
		speed = ($(window).scrollLeft() - 9100)*speedcoef;
		if (speed < 0) speed = speed * (-1);
		$.scrollTo({left:9100, top:$(window).scrollTop()}, speed);
		return false;
	});
	
	$("#controls .button1").click(function() {
		speed = ($(window).scrollLeft() - 0)*speedcoef;
		if (speed < 0) speed = speed * (-1);
		$.scrollTo({left:0, top:$(window).scrollTop()}, speed);
				return false;
	});
	$("#controls .button2").click(function() {
		speed = ($(window).scrollLeft() - 4450)*speedcoef;
		if (speed < 0) speed = speed * (-1);
		$.scrollTo({left:4450, top:$(window).scrollTop()}, speed);
				return false;
	});
	$("#controls .button3").click(function() {
		speed = ($(window).scrollLeft() - 6940)*speedcoef;
		if (speed < 0) speed = speed * (-1);
		$.scrollTo({left:6940, top:$(window).scrollTop()}, speed);
				return false;
	});

})